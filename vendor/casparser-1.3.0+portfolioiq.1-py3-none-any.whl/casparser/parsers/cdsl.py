"""Dedicated CDSL parser.

Like `nsdl_parser`, this consumes structured `Block`/`Cell` data from
`pageobj.extract_blocks` and emits an `NSDLCASData` directly — no
detour through PROD's `process_cdsl_text`.

CDSL CAS layout (in document order; absolute page numbers vary by
holding count):

  - **Cover + account roster** — investor address block followed by the
    "Account Type / Account Details / ISINs / Value" summary table that
    enumerates each demat account and the MF-folios pseudo-account.
  - **Per-MF-folio descriptive blocks** — AMC Name, Scheme Name,
    Folio No, KYC, ISIN/UCC/RTA, one block group per folio. No
    balances here.
  - **Per-account transaction sections + holdings tables** — each
    section starts with `DP Name : <broker> ... BO ID :
    <dpid+clientid>`, followed by transactions, then a
    `HOLDING STATEMENT AS ON` header and the holdings table itself
    (9-10 cells per row).
  - **`MUTUAL FUND UNITS HELD AS ON` table** — one row per MF folio
    with full P&L (scheme name, ISIN, folio, ARN code, units, NAV,
    invested, current value, TER, commission, profit, return%).
  - **Notes / footer** at the end.

Some CDSL PDFs ship with a heavy Hindi-font overlay that makes
roughly half the table cells unreadable by content-stream extraction
(PROD fails on them too). The atom-level overlay filter in
`extract.py` recovers most of these; the remainder need a smarter
font-aware extractor and are out of scope here.
"""

from __future__ import annotations

import re
from decimal import Decimal, InvalidOperation
from typing import Dict, List, Optional, Tuple

from casparser.enums import FileType
from casparser.types import (
    DematAccount,
    DematOwner,
    Equity,
    MutualFund,
    NPSAccount,
    NPSScheme,
    NSDLCASData,
    StatementPeriod,
)

from . import pageobj
from ._investor import extract_nsdl_cdsl_investor
from .pageobj import Block

# --- patterns ---

ISIN_RE = re.compile(r"^[A-Z]{2}[0-9A-Z]{9}\d$")
INF_ISIN_RE = re.compile(r"^INF[0-9A-Z]{8}\d$")
INE_ISIN_RE = re.compile(r"^IN[E9][0-9A-Z]{8}\d$")
# CDSL sometimes drops the leading zero on fractional values (e.g. a
# `0.196` unit balance prints as `.196`), so the integer part is
# optional when a decimal part is present.
NUMERIC_RE = re.compile(r"^-?(?:[\d,]+(?:\.\d+)?|\.\d+)$")
# A long CDSL folio wraps its tail onto the next display line, which the
# extractor emits as a separate cell — e.g. folio "91012112582/0" splits
# into "910121125" | "82/0". The tail is a `<digits>/<digits>` token; we
# splice it back onto the folio head (the on-page hyphen at the wrap is
# only a line-break indicator, absent from the authoritative
# "Folio No :" block).
FOLIO_TAIL_RE = re.compile(r"\d+/\d+")

PERIOD_RE = re.compile(
    r"(?:for\s+the\s+period\s+from|statement\s+for\s+the\s+period\s+from)\s+"
    r"(\d{2}[-/][A-Za-z0-9]{2,3}[-/]\d{4})\s+to\s+(\d{2}[-/][A-Za-z0-9]{2,3}[-/]\d{4})",
    re.I,
)

DEMAT_TYPE_RE = re.compile(r"^(CDSL|NSDL)\s+Demat\s+Account\s*$", re.I)
PAN_RE = re.compile(r"(.+?)\s*\(\s*PAN\s*:\s*([^)]+?)\s*\)", re.I)

# Page-2 summary row carries `DP Id: <dp> Client Id : <client>`
# (whitespace around the colons varies).
SUMMARY_DPC_RE = re.compile(
    r"DP\s*Id\s*:\s*(\S+?)\s+Client\s*Id\s*:\s*(\d+)",
    re.I,
)
# Per-account holdings header: `DP Name : <broker>  DP ID : <dp>
# CLIENT ID : <client>`.
SECTION_DPC_RE = re.compile(
    r"DP\s*Name\s*:\s*(.+?)\s+DP\s*ID\s*:\s*(\S+)\s+CLIENT\s*ID\s*:\s*(\S+)",
    re.I | re.S,
)
# Transaction-page header: `DP Name : <broker>  BO ID : <16-char id>`.
# The id concatenates DP ID + Client ID, both 8 chars. CDSL DP IDs are
# numeric, NSDL DP IDs start with `IN`, so the 16-char field can be all
# digits (CDSL) or two letters + 14 digits (NSDL).
SECTION_BOID_RE = re.compile(
    r"DP\s*Name\s*:\s*(.+?)\s+(?:BO\s*ID|DPID)\s*:\s*([A-Z0-9]{16})",
    re.I | re.S,
)

# --- NPS section patterns ---
# An NPS holding row's scheme name always begins with this marker.
NPS_SCHEME_MARKER = "nps trust"
# `NPS-SP : PROT   PRAN ID : <masked>` — service provider (CRA) + PRAN.
NPS_SP_RE = re.compile(r"NPS[-\s]*SP\s*:\s*([A-Za-z0-9]+)", re.I)
NPS_PRAN_RE = re.compile(r"PRAN\s*ID\s*:\s*([A-Z0-9]+)", re.I)
# `Portfolio Value ` 56,05,171.60 as on 31-03-2026` — reported NPS total.
NPS_VALUE_RE = re.compile(r"Portfolio\s+Value[^\d]*([\d,]+\.\d+)", re.I)
# Tier ("TIER I"/"TIER II") and asset class ("SCHEME E/C/G/A") in the name.
NPS_TIER_RE = re.compile(r"\bTIER\s*[-\s]*(I{1,2}|1|2)\b", re.I)
NPS_ASSET_RE = re.compile(r"\bSCHEME\s+([A-Za-z])\b")
# Text that marks a block as genuine NPS holding content (scheme name /
# fund manager lines). Used to skip page furniture (bank header, tab bar,
# investor name, column headers, "Page N of M" footer) that gets interleaved
# when a scheme row straddles a page break.
NPS_HOLDING_TEXT_RE = re.compile(
    r"NPS\s+TRUST|PENSION\s+FUND|MANAGEMENT\s+LIMITED|SCHEME\s+[A-Z0-9]\s*-\s*TIER",
    re.I,
)
# Minimum x-gap (points) that separates the two text columns (scheme name |
# fund manager). Wrapped lines within a column share an x, so any gap this
# large is a real column boundary — layout-independent, unlike a fixed x.
_NPS_COL_GAP_MIN = 150.0


# --- decimal helpers ---


def _to_decimal(text) -> Decimal:
    if text is None:
        return Decimal(0)
    s = str(text).replace(",", "").strip()
    if not s or s in ("-", "--", "N.A", "NA"):
        return Decimal(0)
    try:
        return Decimal(s)
    except InvalidOperation:
        return Decimal(0)


def _opt_decimal(text) -> Optional[Decimal]:
    if text is None:
        return None
    s = str(text).replace(",", "").strip()
    if not s or s in ("-", "--", "N.A", "NA"):
        return None
    try:
        return Decimal(s)
    except InvalidOperation:
        return None


def _looks_numeric(text: str) -> bool:
    s = text.strip()
    if not s:
        return False
    return bool(NUMERIC_RE.match(s))


def _rel_close(a: Decimal, b: Decimal, rel: Decimal = Decimal("0.005")) -> bool:
    if b == 0:
        return abs(a) <= Decimal("0.01")
    return abs(a - b) / abs(b) <= rel


def _resolve_cdsl_mf_pnl_returns(
    numerics: List[str],
    value: Decimal,
    invested: Optional[Decimal],
    has_distrib_col: bool,
) -> Tuple[Optional[Decimal], Optional[Decimal]]:
    """Assign profit and return% from the post-value numeric tail.

    Positional ``numerics[-2]`` / ``[-1]`` is wrong when the statement
    omits a printed profit column and only shows return% — identity
    ``value - invested`` picks profit when present; otherwise leave
    ``pnl`` unset and treat a small trailing % as ``return_``."""
    if not has_distrib_col:
        return None, None

    value_idx = 3 if len(numerics) >= 4 else 2
    remaining = [_to_decimal(n) for n in numerics[value_idx + 1 :]]
    remaining = [r for r in remaining if r != 0]

    expected_pnl: Optional[Decimal] = None
    if invested is not None and invested > 0:
        expected_pnl = value - invested

    pnl: Optional[Decimal] = None
    ret: Optional[Decimal] = None

    if expected_pnl is not None:
        for r in remaining:
            if _rel_close(r, expected_pnl):
                pnl = r
                break
        if pnl is None and len(numerics) >= 6:
            pos_pnl = _opt_decimal(numerics[-2])
            if pos_pnl is not None and _rel_close(pos_pnl, expected_pnl):
                pnl = pos_pnl

    others = [r for r in remaining if r != pnl]
    if pnl is not None and others:
        ret = others[-1]
    elif pnl is None and expected_pnl is not None:
        for r in others:
            if abs(r) < Decimal("100"):
                ret = r
                break
    elif len(numerics) >= 5:
        ret = _opt_decimal(numerics[-1])

    if pnl == 0:
        pnl = None
    if ret == 0:
        ret = None
    return pnl, ret


# --- account key utilities ---


def _full_type(type_word: str) -> str:
    return f"{type_word.upper()} Demat Account"


def _account_key(type_word: str, dp_id: str, client_id: str) -> Tuple[str, str, str]:
    return (type_word.upper(), dp_id.strip(), client_id.strip())


def _split_bo_id(bo_id: str) -> Tuple[str, str, str]:
    """16-char BO ID → `(type_word, dp_id, client_id)`.

    NSDL DP IDs start with `IN` (8 chars total), CDSL DP IDs are pure
    digits. Both followed by an 8-digit Client ID."""
    if len(bo_id) != 16:
        return "", "", ""
    if bo_id[:2].upper() == "IN":
        return "NSDL", bo_id[:8], bo_id[8:]
    if bo_id.isdigit():
        return "CDSL", bo_id[:8], bo_id[8:]
    return "", "", ""


# --- parser entry point ---


def _norm_tier(t: str) -> str:
    return {"1": "I", "2": "II"}.get(t.upper(), t.upper())


def _is_nps_holding_block(block: Block) -> bool:
    """True when a block is part of an NPS holding row — it carries a numeric
    (units/nav) cell or scheme/fund-manager text. Everything else in the
    holding region (bank header, tab bar, investor name, column headers,
    "Page N of M" footer) is page furniture and is skipped."""
    for c in block.cells:
        if _looks_numeric(c.text):
            return True
        if NPS_HOLDING_TEXT_RE.search(c.text):
            return True
    return False


def _build_nps_scheme(cells: list) -> Optional[NPSScheme]:
    """Build one NPSScheme from an accumulated holding-row cell buffer.

    A scheme row spans several extractor lines: two text columns (scheme
    name, fund manager) and two numeric cells (units, then nav). Text is
    grouped into the two columns by a coarse x split; the numeric cells are
    assigned by order (left = units, right = nav). value = units * nav.
    Rows without both numerics (e.g. redacted) are skipped.
    """
    text_cells = [c for c in cells if c.text.strip() and not _looks_numeric(c.text)]
    num_cells = sorted((c for c in cells if _looks_numeric(c.text)), key=lambda c: c.x_left)
    # Split the two text columns (scheme name | fund manager) by the largest
    # x-gap rather than a fixed threshold — column x-positions drift between
    # CAS versions. Left cluster = scheme name, right = fund manager.
    by_x = sorted(text_cells, key=lambda c: c.x_left)
    split = len(by_x)
    if len(by_x) >= 2:
        max_gap, at = max(
            (by_x[i + 1].x_left - by_x[i].x_left, i + 1) for i in range(len(by_x) - 1)
        )
        if max_gap >= _NPS_COL_GAP_MIN:
            split = at
    name_cells = sorted(by_x[:split], key=lambda c: -c.y_top)
    fm_cells = sorted(by_x[split:], key=lambda c: -c.y_top)
    scheme = " ".join(c.text.replace("\n", " ").strip() for c in name_cells).strip()
    scheme = re.sub(r"\s+", " ", scheme)
    if NPS_SCHEME_MARKER not in scheme.lower():
        return None
    if len(num_cells) < 2:
        return None  # units / nav not present (redacted) — cannot form a holding
    fund_manager = " ".join(c.text.replace("\n", " ").strip() for c in fm_cells).strip()
    fund_manager = re.sub(r"\s+", " ", fund_manager) or None
    units = _to_decimal(num_cells[0].text)
    nav = _to_decimal(num_cells[1].text)
    tier = None
    if m := NPS_TIER_RE.search(scheme):
        tier = _norm_tier(m.group(1))
    asset_class = None
    if m := NPS_ASSET_RE.search(scheme):
        asset_class = m.group(1).upper()
    return NPSScheme(
        scheme=scheme,
        fund_manager=fund_manager,
        tier=tier,
        asset_class=asset_class,
        units=units,
        nav=nav,
        value=(units * nav).quantize(Decimal("0.01")),
    )


def _parse_nps(blocks: List[Block]) -> Optional[NPSAccount]:
    """Extract the NPS holdings section (if present) from a CDSL CAS.

    Holdings only — the NPS transaction statement is intentionally not
    parsed. Scans for the NPS `HOLDING STATEMENT` region (identified by its
    `NPS TRUST-` scheme rows) and reads scheme name / fund manager /
    units / nav; PRAN + NPS-SP + reported portfolio value from the section
    text. Returns None when the CAS has no NPS section.
    """
    nps_sp: Optional[str] = None
    pran: Optional[str] = None
    value: Optional[Decimal] = None
    schemes: List[NPSScheme] = []
    mode: Optional[str] = None  # None | "txn" | "holding"
    buf: list = []

    def flush() -> None:
        nonlocal buf
        if buf:
            sc = _build_nps_scheme(buf)
            if sc is not None:
                schemes.append(sc)
            buf = []

    for b in blocks:
        txt = b.text()
        low = txt.lower()
        if nps_sp is None and (m := NPS_SP_RE.search(txt)):
            nps_sp = m.group(1)
        if pran is None and (m := NPS_PRAN_RE.search(txt)):
            pran = m.group(1)
        if "statement of transactions" in low:
            flush()
            mode = "txn"
            continue
        if "holding statement" in low and "as on" in low:
            flush()
            mode = "holding"
            continue
        if "portfolio value" in low:
            # Closes the NPS holding region; capture the reported total only
            # when we are actually closing NPS holdings (schemes seen).
            if (schemes or buf) and (m := NPS_VALUE_RE.search(txt)):
                value = _to_decimal(m.group(1))
            flush()
            mode = None
            continue
        if "nps investment summary" in low:
            flush()
            mode = None
            continue
        if mode != "holding":
            continue
        starts_scheme = any(c.text.strip().lower().startswith(NPS_SCHEME_MARKER) for c in b.cells)
        if starts_scheme:
            flush()
            buf = list(b.cells)
        elif buf and _is_nps_holding_block(b):
            # Only holding content extends the row buffer; page furniture
            # (bank header, tab bar, investor name, column headers, footer)
            # interleaved across a page break is skipped so it doesn't leak
            # into the scheme name of a row that straddles two pages.
            buf.extend(b.cells)
    flush()

    if not schemes and value is None and nps_sp is None and pran is None:
        return None
    if value is None:
        value = sum((s.value for s in schemes), Decimal(0))
    return NPSAccount(pran=pran, nps_sp=nps_sp, value=value, schemes=schemes)


def parse_cdsl(
    pdf_path: str,
    password: str,
    file_type: FileType = FileType.CDSL,
    *,
    _doc=None,
) -> NSDLCASData:
    atoms = pageobj.extract_atoms(pdf_path, password, _doc=_doc)
    blocks = pageobj.blocks_from_atoms(atoms)
    period = _find_period(blocks) or StatementPeriod(**{"from": "", "to": ""})

    # Phase 1: account roster from page 2 summary.
    accounts_by_key: Dict[Tuple[str, str, str], DematAccount] = {}
    ordered_accounts: List[DematAccount] = []
    mf_folios_account: Optional[DematAccount] = None
    pending_owners: List[DematOwner] = []

    for b in blocks:
        if b.page != 2:
            continue
        txt = b.text()
        ltxt = txt.lower()
        if "in the single name of" in ltxt or "in the joint name" in ltxt:
            pending_owners = []
            continue
        if PAN_RE.search(txt) and "Mutual" not in txt:
            for m in PAN_RE.finditer(txt):
                pending_owners.append(
                    DematOwner(
                        name=m.group(1).strip(),
                        PAN=m.group(2).strip(),
                    )
                )
            continue
        if _is_summary_demat_row(b):
            ac, key = _account_from_summary_row(b, pending_owners)
            if key not in accounts_by_key:
                accounts_by_key[key] = ac
                ordered_accounts.append(ac)
            continue
        if _is_summary_mf_folios_row(b):
            if mf_folios_account is None:
                mf_folios_account = _mf_folios_account_from_summary(b, pending_owners)
                ordered_accounts.append(mf_folios_account)
            continue

    # Phase 2: scheme-code → (ISIN, UCC, folio, name) map from the
    # descriptive MF blocks that follow the roster page. Their page
    # span depends on how many MF folios the investor holds; we
    # bound-scan from page 3 up to the start of the per-account
    # transaction section (detected via the `BO ID :` / `DPID :`
    # marker), and only consume blocks that match the descriptive
    # template (Scheme Name + Scheme Code + ISIN + UCC).
    scheme_meta: Dict[str, Dict[str, str]] = {}
    pending_scheme: Dict[str, str] = {}
    for b in blocks:
        if b.page < 3:
            continue
        if SECTION_BOID_RE.search(b.text()):
            break
        txt = b.text()
        if "Scheme Name :" in txt and "Scheme Code :" in txt:
            sm = re.search(
                r"Scheme\s*Name\s*:\s*(.+?)\s+Scheme\s*Code\s*:\s*(\S+)",
                txt,
                re.S,
            )
            if sm:
                pending_scheme = {
                    "scheme_name": sm.group(1).replace("\n", " ").strip(),
                    "scheme_code": sm.group(2).strip(),
                }
        elif "Folio No :" in txt:
            fm = re.search(r"Folio\s*No\s*:\s*(\S+)", txt)
            if fm:
                pending_scheme["folio"] = fm.group(1)
        elif "ISIN :" in txt and "UCC" in txt:
            im = re.search(r"ISIN\s*:\s*(\S+)", txt)
            um = re.search(r"UCC\s*:\s*([\w/]+)?", txt)
            if im and pending_scheme.get("scheme_code"):
                pending_scheme["isin"] = im.group(1)
                if um and um.group(1):
                    pending_scheme["ucc"] = um.group(1)
                scheme_meta[pending_scheme["scheme_code"]] = dict(pending_scheme)
                pending_scheme = {}

    # Phase 3: walk all post-cover pages for holdings tables.
    # We skip pages 1-2 (cover + roster) because the roster lines
    # contain CDSL/NSDL identifiers that would otherwise look like
    # section headers; the dispatch logic below handles the rest.
    cur_account: Optional[DematAccount] = None
    cur_mode: Optional[str] = None  # 'equities' | 'mf_holdings'

    for b in blocks:
        if b.page < 3:
            continue
        txt = b.text()
        ltxt = txt.lower()

        # Per-account section header — `DP Name : ... BO ID : ...`
        # or `DP Name : ... DPID : ...` (NSDL variant) form.
        m = SECTION_BOID_RE.search(txt)
        if m:
            broker = m.group(1).strip()
            bo_id = m.group(2)
            type_word, dp_id, client_id = _split_bo_id(bo_id)
            if type_word:
                ac_key = _account_key(type_word, dp_id, client_id)
                cur_account = accounts_by_key.get(ac_key)
                cur_mode = None
                continue

        # Or "DP Name : ... DP ID : ... CLIENT ID : ..."
        m = SECTION_DPC_RE.search(txt)
        if m:
            type_word = "CDSL"
            if "NSDL" in txt.upper() and "CDSL" not in txt.upper():
                type_word = "NSDL"
            broker, dp_id, client_id = m.groups()
            ac_key = _account_key(type_word, dp_id.strip(), client_id.strip())
            cur_account = accounts_by_key.get(ac_key)
            cur_mode = None
            continue

        # Transaction-statement section — switch OFF holdings mode so
        # transaction rows aren't parsed as equity rows.
        if "statement of transactions" in ltxt:
            cur_mode = None
            continue

        # Holdings section markers
        if "holding statement" in ltxt and "as on" in ltxt:
            cur_mode = "equities"
            continue
        if "mutual fund units held as on" in ltxt:
            cur_account = mf_folios_account
            cur_mode = "mf_holdings"
            continue

        # Skip column-header rows
        if _is_holdings_header(b) or _is_total_row(b):
            continue

        # Holdings rows
        if cur_account is None or cur_mode is None:
            continue
        if cur_mode == "equities":
            row = _parse_holdings_row(b)
            if row is None:
                pass
            else:
                isin, name, num_shares, price, value = row
                # CDSL Demat statements list ETFs (ISIN starting with
                # INF) in the same holdings table as equities, but
                # they're semantically mutual-fund units. Route them
                # to the mutual_funds list to mirror PROD's
                # classification.
                if INF_ISIN_RE.match(isin):
                    cur_account.mutual_funds.append(
                        MutualFund(
                            name=name,
                            isin=isin,
                            balance=num_shares,
                            nav=price,
                            value=value,
                        )
                    )
                else:
                    cur_account.equities.append(
                        Equity(
                            name=name,
                            isin=isin,
                            num_shares=num_shares,
                            price=price,
                            value=value,
                        )
                    )
        elif cur_mode == "mf_holdings":
            mf = _parse_mf_holdings_row(b, scheme_meta)
            if mf:
                cur_account.mutual_funds.append(mf)

    return NSDLCASData(
        statement_period=period,
        accounts=ordered_accounts,
        investor_info=extract_nsdl_cdsl_investor(
            pdf_path,
            password,
            _atoms=atoms,
        ),
        file_type=file_type,
        nps=_parse_nps(blocks),
    )


# --- summary-row recognisers (page 2) ---


def _is_summary_demat_row(block: Block) -> bool:
    if len(block.cells) != 4:
        return False
    if not DEMAT_TYPE_RE.match(block.cells[0].text.strip()):
        return False
    return bool(SUMMARY_DPC_RE.search(block.cells[1].text))


def _is_summary_mf_folios_row(block: Block) -> bool:
    if len(block.cells) != 4:
        return False
    return bool(re.match(r"^Mutual\s+Fund\s+Folios", block.cells[0].text.strip(), re.I))


def _account_from_summary_row(
    block: Block, owners: List[DematOwner]
) -> Tuple[DematAccount, Tuple[str, str, str]]:
    type_word = DEMAT_TYPE_RE.match(block.cells[0].text.strip()).group(1).upper()
    broker_dp = block.cells[1].text
    lines = [ln.strip() for ln in broker_dp.split("\n") if ln.strip()]
    broker = lines[0] if lines else ""
    dpc = SUMMARY_DPC_RE.search(broker_dp)
    dp_id = dpc.group(1) if dpc else ""
    client_id = dpc.group(2) if dpc else ""
    folios = int(_to_decimal(block.cells[2].text))
    balance = _to_decimal(block.cells[3].text)
    ac = DematAccount(
        name=broker,
        type=_full_type(type_word),
        dp_id=dp_id,
        client_id=client_id,
        folios=folios,
        balance=balance,
        owners=list(owners),
        equities=[],
        mutual_funds=[],
    )
    return ac, _account_key(type_word, dp_id, client_id)


def _mf_folios_account_from_summary(block: Block, owners: List[DematOwner]) -> DematAccount:
    folios_m = re.search(r"(\d+)", block.cells[1].text)
    folios = int(folios_m.group(1)) if folios_m else 0
    balance = _to_decimal(block.cells[3].text)
    return DematAccount(
        name="Mutual Fund Folios",
        type="Mutual Fund Folios",
        dp_id="",
        client_id="",
        folios=folios,
        balance=balance,
        owners=list(owners),
        equities=[],
        mutual_funds=[],
    )


# --- helpers ---


def _find_period(blocks: List[Block]) -> Optional[StatementPeriod]:
    for b in blocks:
        m = PERIOD_RE.search(b.text())
        if m:
            return StatementPeriod(**{"from": m.group(1), "to": m.group(2)})
    return None


def _is_holdings_header(block: Block) -> bool:
    """Block has no ISIN and looks like a column-label row."""
    txt = block.text()
    if re.search(r"\b(IN[EF9][0-9A-Z]{8}\d)\b", txt, re.I):
        return False
    ltxt = txt.lower().replace("\n", " ").replace("\t\t", " ")
    if "isin" in ltxt and ("security" in ltxt or "scheme name" in ltxt):
        return True
    if "current" in ltxt and "bal" in ltxt and "market" in ltxt:
        return True
    return False


def _is_total_row(block: Block) -> bool:
    first = block.cells[0].text.strip().lower() if block.cells else ""
    return first in ("sub total", "total", "grand total")


# --- equity holdings row ---


def _parse_holdings_row(block: Block) -> Optional[Tuple[str, str, Decimal, Decimal, Decimal]]:
    """CDSL holdings row → `(isin, name, num_shares, price, value)`.

    Column layout (post-`HOLDING STATEMENT`):
      ISIN | Security | Current Bal | Frozen Bal | Pledge Bal |
      Pledge Setup Bal | Free Bal | Market Price | Value (`)

    A few rows have a leading '@' marker cell between ISIN and name
    (suspended issue notation). Rows with all-`--` quantity cells
    (rights entitlements that haven't been exercised) are still
    parsed — `_to_decimal` maps `--` to 0. We use position-based
    assignment, not the last-three-numerics heuristic, because some
    rows have only 2 numeric cells (price + value) when all balance
    columns are `--`."""
    if not block.cells:
        return None
    first = block.cells[0].text.strip()
    if not ISIN_RE.match(first):
        return None
    isin = first

    # Find the data-cell boundary: the first cell after ISIN whose
    # text is a number or `--`. Everything between ISIN and that cell
    # is part of the security name (PDF renderer sometimes splits
    # multi-line security names across several cells with different
    # x-positions).
    data_start = None
    for i in range(1, len(block.cells)):
        t = block.cells[i].text.strip()
        if _looks_numeric(t) or t in ("--", "-"):
            data_start = i
            break
    if data_start is None or len(block.cells) - data_start < 3:
        return None
    name = (
        " ".join(
            c.text.replace("\n", " ").strip()
            for c in block.cells[1:data_start]
            if c.text.strip() and c.text.strip() not in ("@",)
        )
        or None
    )

    num_shares = _to_decimal(block.cells[data_start].text)
    price = _to_decimal(block.cells[-2].text)
    value = _to_decimal(block.cells[-1].text)
    return isin, name, num_shares, price, value


# --- MF holdings row (the `MUTUAL FUND UNITS HELD AS ON` section) ---


def _parse_mf_holdings_row(
    block: Block,
    scheme_meta: Dict[str, Dict[str, str]],
) -> Optional[MutualFund]:
    """MF holdings table row. Known templates:

    - **Full, with distribution-mode column (13 cells)**:
        name | ISIN | folio | ARN-or-DIRECT | units | NAV | invested
        | value | TER% | direct | commission | profit | return%

    - **Without distribution-mode column (7 cells)**:
        name | ISIN | folio | units | NAV | invested | value

    - **Reduced, with distribution-mode column (7 cells)**:
        name | ISIN | folio | ARN-or-DIRECT | units | NAV | value
        (no separate "invested / total cost" column)

    Discriminator: the cell two positions after the ISIN. In the
    distribution-mode layouts it carries an alphanumeric label
    (`ARN-####`, `DIRECT`, sometimes a folio-split fragment like
    `4/0`); otherwise it's the units value (a pure number).

    We then filter the cells after `data_start` to numeric tokens. The
    leading two are always units + NAV; the *current value* is the next
    column when it's the last one (reduced row) or the column after
    "invested" otherwise. A holdings statement always prints the
    current value, so when only three numerics survive we treat the
    third as the value (not the optional invested/cost column).
    """
    if len(block.cells) < 5:
        return None
    # Find the ISIN cell — usually cell 1.
    isin_idx = None
    for i in range(min(3, len(block.cells))):
        s = block.cells[i].text.strip()
        if ISIN_RE.match(s):
            isin_idx = i
            break
    if isin_idx is None:
        return None
    isin = block.cells[isin_idx].text.strip()

    # Name is whatever precedes the ISIN, joined.
    name = (
        " ".join(
            c.text.replace("\n", " ").strip() for c in block.cells[:isin_idx] if c.text.strip()
        )
        or None
    )

    # Folio = cell right after ISIN (`<digits>/<digits>` or just digits).
    folio = None
    folio_end = isin_idx + 1
    if isin_idx + 1 < len(block.cells):
        folio = block.cells[isin_idx + 1].text.strip() or None

    # A long folio wraps its tail into the NEXT cell:
    #   "910121125" | "82/0" | DIRECT | units | ...
    # The real folio "91012112582/0" is split across two cells. Splice
    # the `<digits>/<digits>` tail back on (no separator — the on-page
    # hyphen is just the wrap indicator); otherwise the folio is
    # truncated to its head and the tail is mistaken for the
    # distribution-mode column below.
    if folio and isin_idx + 2 < len(block.cells):
        tail = block.cells[isin_idx + 2].text.strip()
        if FOLIO_TAIL_RE.fullmatch(tail):
            folio = folio + tail
            folio_end = isin_idx + 2

    # Discriminate 13-cell (has ARN/DIRECT) vs 7-cell (no such column).
    # The distribution-mode discriminator is the cell right after the
    # folio (which may span two cells when it wrapped).
    disc_idx = folio_end + 1
    has_distrib_col = disc_idx < len(block.cells) and not _looks_numeric(block.cells[disc_idx].text)
    data_start = disc_idx + (1 if has_distrib_col else 0)
    numerics = [c.text.strip() for c in block.cells[data_start:] if _looks_numeric(c.text)]
    if len(numerics) < 3:
        return None
    balance = _to_decimal(numerics[0])
    nav = _to_decimal(numerics[1])
    if len(numerics) >= 4:
        # units | NAV | invested | value | [TER, commission, profit, return]
        invested = _opt_decimal(numerics[2])
        value = _to_decimal(numerics[3])
    else:
        # Reduced row: units | NAV | value (no separate invested/cost).
        invested = None
        value = _to_decimal(numerics[2])
    pnl, ret = _resolve_cdsl_mf_pnl_returns(numerics, value, invested, has_distrib_col)

    # Pull UCC from scheme_meta keyed on scheme_code (prefix of name)
    ucc = None
    if name:
        code_m = re.match(r"\s*([A-Z0-9]+)\s*-\s*", name)
        if code_m:
            meta = scheme_meta.get(code_m.group(1))
            if meta:
                ucc = meta.get("ucc")

    return MutualFund(
        name=name,
        isin=isin,
        balance=balance,
        nav=nav,
        value=value,
        total_cost=invested,
        ucc=ucc,
        folio=folio,
        pnl=pnl,
        **{"return": ret},
    )
